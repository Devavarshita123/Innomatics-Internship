class Solution:
    def shuffle(self, nums: List[int], n: int) -> List[int]:
        result = [0] * len(nums)
        index = 0
        middle = len(nums) // 2

        for i in range(middle):
            result[index] = nums[i]
            index += 1
            result[index] = nums[i + middle]
            index += 1

        return result
